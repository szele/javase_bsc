package HtmlBuilder;


import java.util.ArrayList;
import java.util.List;

public class ContainerElement extends BasicHtmlElement {


    private List<HTMLElement> elements = new ArrayList<HTMLElement>();

    public void addElement(HTMLElement element) { elements.add(element);};
    public void addElement(String      element) { elements.add( new SimpleText(element));};


    @Override
    protected String getContent() {
        String html = "";
        for (HTMLElement elem: elements)
        {
            html+=elem.toHtml();
        };
        return html;
    }



}
