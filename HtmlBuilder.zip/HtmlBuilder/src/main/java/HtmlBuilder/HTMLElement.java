package HtmlBuilder;



public interface HTMLElement {

    public String toHtml();

}
