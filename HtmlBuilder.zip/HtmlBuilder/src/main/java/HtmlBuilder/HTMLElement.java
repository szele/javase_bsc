package HtmlBuilder;



public interface HTMLElement {

    String toHtml();

}
