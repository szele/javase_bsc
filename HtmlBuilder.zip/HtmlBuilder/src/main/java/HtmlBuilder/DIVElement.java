

package HtmlBuilder;



public class DIVElement extends ContainerElement {

    public DIVElement() {

        name = "div";
    }

    public void setId(String id) { super.setProperty("id", id); };
}
