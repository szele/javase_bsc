

package HtmlBuilder;



public class SimpleText implements HTMLElement {

    private String text;


    public SimpleText(String text) {this.text  = text; };


    @Override
    public String toHtml() {

        return text;
    }

}
