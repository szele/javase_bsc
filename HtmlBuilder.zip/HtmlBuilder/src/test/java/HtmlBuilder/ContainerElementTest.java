package HtmlBuilder;

import org.junit.jupiter.api.Test;

class ContainerElementTest {

    @Test
    void getContent() {
    }

    @Test
    void setProperty() {
    }

    @Test
    void getProperty() {
    }

    @Test
    void toHtml() {
    }

    @Test
    void addElement() {
    }

    @Test
    void testAddElement() {
    }

    @Test
    void testGetContent() {
    }
}