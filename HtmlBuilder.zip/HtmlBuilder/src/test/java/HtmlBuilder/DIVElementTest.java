package HtmlBuilder;

import org.junit.jupiter.api.Test;

class DIVElementTest {

    @Test
    void addElement() {
    }

    @Test
    void testAddElement() {
    }

    @Test
    void getContent() {
    }

    @Test
    void testGetContent() {
    }

    @Test
    void setProperty() {
    }

    @Test
    void getProperty() {
    }

    @Test
    void toHtml() {
    }

    @Test
    void setId() {
    }
}