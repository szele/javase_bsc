package HtmlBuilder;

import org.junit.jupiter.api.Test;

class BasicHtmlElementTest {

    @Test
    void getContent() {
    }

    @Test
    void setProperty() {
    }

    @Test
    void getProperty() {
    }

    @Test
    void toHtml() {
    }
}